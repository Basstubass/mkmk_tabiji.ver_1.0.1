Travel Search

## Installation
- VisualStudio Code, Extension(SQlite, Python)

## Configuration
- Python 3.7
- Flask 2.0

## Design
- ERD

## Document
- Google Drive: [mkmk]https://drive.google.com/drive/u/2/folders/1GT_XGjXqLWWXz70aqTEtUVLacPnadli2

## Troubleshooting

## Contribution
mkmkによるチーム開発
